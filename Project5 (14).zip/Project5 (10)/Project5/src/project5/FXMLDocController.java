/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project5;

import java.io.File;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.text.TextFlow;


//import javafx.scene.control.Label;

/**
 *
 * @author bdtra
 */
public class FXMLDocController implements Initializable {
    
    @FXML
    private Stage stage;
    private Scene scene;
    private Parent root;
    //private Label label;
//    @FXML
//    private ComboBox comb;
//    @FXML
//    private Label label2;
//    @FXML
//    private Button Button;
//    @FXML
//    private Button Button2;
    //private Button Button3;
    
//    @FXML
//    ImageView myImageView;
    @FXML
    Image myImage = new Image(getClass().getResourceAsStream("Temp.jpg"));
    Image myImage2 = new Image(getClass().getResourceAsStream("CarbonDioxide.jpg"));
    Image myImage3 = new Image(getClass().getResourceAsStream("SeaIceExtent.jpg"));
    Image myImage4 = new Image(getClass().getResourceAsStream("IceSheets.jpg"));
    Image myImage5 = new Image(getClass().getResourceAsStream("SeaLevel.jpg"));
    Image myImage6 = new Image(getClass().getResourceAsStream("OceanWarming.jpg"));
    Image screenshot108 = new Image(getClass().getResourceAsStream("Screenshot (108).png"));
    Image screenshot109 = new Image(getClass().getResourceAsStream("Screenshot (109).png"));
    Image screenshot110 = new Image(getClass().getResourceAsStream("Screenshot (110).png"));
    Image screenshot111 = new Image(getClass().getResourceAsStream("Screenshot (111).png"));
    Image screenshot112 = new Image(getClass().getResourceAsStream("Screenshot (112).png"));
    Image screenshot113 = new Image(getClass().getResourceAsStream("Screenshot (113).png"));
    Image screenshot114 = new Image(getClass().getResourceAsStream("Screenshot (114).png"));
    Image screenshot115 = new Image(getClass().getResourceAsStream("Screenshot (115).png"));
    Image screenshot116 = new Image(getClass().getResourceAsStream("Screenshot (116).png"));
    Image screenshot117 = new Image(getClass().getResourceAsStream("Screenshot (117).png"));
    Image screenshot118 = new Image(getClass().getResourceAsStream("Screenshot (118).png"));
    Image screenshot119 = new Image(getClass().getResourceAsStream("Screenshot (119).png"));
    Image screenshot120 = new Image(getClass().getResourceAsStream("Screenshot (120).png"));
    Image screenshot121 = new Image(getClass().getResourceAsStream("Screenshot (121).png"));
    Image screenshot122 = new Image(getClass().getResourceAsStream("Screenshot (122).png"));
    Image screenshot123 = new Image(getClass().getResourceAsStream("Screenshot (123).png"));
    Image screenshot124 = new Image(getClass().getResourceAsStream("Screenshot (124).png"));
    Image screenshot125 = new Image(getClass().getResourceAsStream("Screenshot (125).png"));
    Image screenshot126 = new Image(getClass().getResourceAsStream("Screenshot (126).png"));
    Image screenshot127 = new Image(getClass().getResourceAsStream("Screenshot (127).png"));
    Image screenshot128 = new Image(getClass().getResourceAsStream("Screenshot (128).png"));
    Image screenshot129 = new Image(getClass().getResourceAsStream("Screenshot (129).png"));
    Image screenshot130 = new Image(getClass().getResourceAsStream("Screenshot (130).png"));
    Image screenshot131 = new Image(getClass().getResourceAsStream("Screenshot (131).png"));
    Image screenshot132 = new Image(getClass().getResourceAsStream("Screenshot (132).png"));
    Image screenshot133 = new Image(getClass().getResourceAsStream("Screenshot (133).png"));
    Image screenshot134 = new Image(getClass().getResourceAsStream("Screenshot (134).png"));
    Image screenshot135 = new Image(getClass().getResourceAsStream("Screenshot (135).png"));
    Image screenshot136 = new Image(getClass().getResourceAsStream("Screenshot (136).png"));
    Image screenshot137 = new Image(getClass().getResourceAsStream("Screenshot (137).png"));
    Image screenshot138 = new Image(getClass().getResourceAsStream("Screenshot (138).png"));
    Image screenshot139 = new Image(getClass().getResourceAsStream("Screenshot (139).png"));
    Image screenshot140 = new Image(getClass().getResourceAsStream("Screenshot (140).png"));
    Image screenshot141 = new Image(getClass().getResourceAsStream("Screenshot (141).png"));
    
    @FXML
    ImageView myImageView2;
    @FXML
    ImageView myImageView3;
    @FXML
    ImageView myImageView4;
    
//    
    @FXML
    TextArea txtField;
//    @FXML
    int i = 0;

    
    
    
    
    public void ifButtonClicked()
    {
        i++;
        if(i==1)
        {
            myImageView4.setImage(screenshot108);
        }
        else if(i==2)
        {
            myImageView4.setImage(screenshot109);
        }
        else if(i==3)
        {
            myImageView4.setImage(screenshot110);
        }
        else if(i==4)
        {
            myImageView4.setImage(screenshot111);
        }
        else if(i==5)
        {
            myImageView4.setImage(screenshot112);
        }
        else if(i==6)
        {
            myImageView4.setImage(screenshot113);
        }
        else if(i==7)
        {
            myImageView4.setImage(screenshot114);
        }
        else if(i==8)
        {
            myImageView4.setImage(screenshot115);
        }
        else if(i==9)
        {
            myImageView4.setImage(screenshot116);
        }
        else if(i==10)
        {
            myImageView4.setImage(screenshot117);
        }
        else if(i==11)
        {
            myImageView4.setImage(screenshot118);
        }
        else if(i==12)
        {
            myImageView4.setImage(screenshot119);
        }
        else if(i==13)
        {
            myImageView4.setImage(screenshot120);
        }
        else if(i==14)
        {
            myImageView4.setImage(screenshot121);
        }
        else if(i==15)
        {
            myImageView4.setImage(screenshot122);
        }
        else if(i==16)
        {
            myImageView4.setImage(screenshot123);
        }
        else if(i==17)
        {
            myImageView4.setImage(screenshot124);
        }
        else if(i==18)
        {
            myImageView4.setImage(screenshot125);
        }
        else if(i==19)
        {
            myImageView4.setImage(screenshot126);
        }
        else if(i==20)
        {
            myImageView4.setImage(screenshot127);
        }
        else if(i==21)
        {
            myImageView4.setImage(screenshot128);
        }
        else if(i==22)
        {
            myImageView4.setImage(screenshot129);
        }
        else if(i==23)
        {
            myImageView4.setImage(screenshot130);
        }
        else if(i==24)
        {
            myImageView4.setImage(screenshot131);
        }
        else if(i==25)
        {
            myImageView4.setImage(screenshot132);
        }
        else if(i==26)
        {
            myImageView4.setImage(screenshot133);
        }
        else if(i==27)
        {
            myImageView4.setImage(screenshot134);
        }
        else if(i==28)
        {
            myImageView4.setImage(screenshot135);
        }
        else if(i==29)
        {
            myImageView4.setImage(screenshot136);
        }
        else if(i==30)
        {
            myImageView4.setImage(screenshot137);
        }
        else if(i==31)
        {
            myImageView4.setImage(screenshot138);
        }
        else if(i==32)
        {
            myImageView4.setImage(screenshot139);
        }
        else if(i==33)
        {
            myImageView4.setImage(screenshot140);
        }
        else if(i==34)
        {
            myImageView4.setImage(screenshot141);
        }
    }
    
    
    
    
    
    
    
    
   
    public void displayImage() {
       myImageView2.setImage(myImage);
       txtField.setWrapText(true);
       txtField.setText("Earth’s global average surface temperature in 2020 tied with 2016 as the hottest year on record, continuing a long-term warming trend due to human activities.\n");
    }
    
    public void displayImage2() {
        myImageView2.setImage(myImage2);
        txtField.setWrapText(true);
        txtField.setText("Carbon dioxide in the atmosphere warms the planet, causing climate change. Human activities have raised the atmosphere’s carbon dioxide content by 50% in less than 200 years.");
    }
    
    public void displayImage3() {
        myImageView2.setImage(myImage3);
        txtField.setWrapText(true);
        txtField.setText("Summer Arctic sea ice extent is shrinking by 12.6% per decade as a result of global warming.");

        
    }
    
    public void displayImage4() {
        myImageView2.setImage(myImage4);
        txtField.setWrapText(true);
        txtField.setText("Antarctica is losing ice mass (melting) at an average rate of about 150 billion tons per year, and Greenland is losing about 280 billion tons per year, adding to sea level rise.");

    }
    
    public void displayImage5() {
        myImageView2.setImage(myImage5);
        txtField.setWrapText(true);
        txtField.setText("Global sea levels are rising as a result of human-caused global warming, with recent rates being unprecedented over the past 2,500-plus years.");        

    }
    
    public void displayImage6() {
        myImageView2.setImage(myImage6);
         txtField.setWrapText(true);
        txtField.setText("Heat stored in the ocean causes its water to expand, which is responsible for one-third to one-half of global sea level rise. Most of the added energy is stored at the surface, at a depth of zero to 700 meters. The last 10 years were the ocean’s warmest decade since at least the 1800s. The year 2021 was the ocean’s warmest recorded year and saw the highest global sea level.");        


    }
//    
    
    public void switchToScene1(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SceneOne1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        
    }
     
    public void switchToScene2(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SceneTwo2.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToScene3(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SceneThree3.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
//        myImageView4.setImage(screenshot108);
        //
        
    
    }
     public void switchToScene4(ActionEvent event) throws IOException
    {
        root = FXMLLoader.load(getClass().getResource("SceneFour4.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
     
//    private void handleButtonAction(ActionEvent event) {
//        System.out.println("Open up Graphs");
//        label.setText("Graphs");
//        
//    }
    /*private void handleButtonAction2(ActionEvent event) {
        
        
    }
    @Override
     */

    //ComboCode Starts here
   
    

//    @FXML
//    void Select(ActionEvent event) {
//        String s = comb.getSelectionModel().getSelectedItem().toString();
//        //label2.setText(s);
//        if("Global temperature".equals(s))
//        {
//               displayImage();
//    }
//        if("Carbon dioxide".equals(s)) {
//            displayImage2();
//        }
//        
//        if ("SIE".equals(s)) {
//            displayImage3();
//        }
//        
//        if ("Ice sheets".equals(s)) {
//            displayImage4();
//        }
//        
//        if ("Sea level".equals(s)) {
//            displayImage5();
//        }
//        
//        if ("Ocean warming".equals(s)) {
//            displayImage6();
//        }
//       
//    }   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
//         ObservableList<String> list = FXCollections.observableArrayList("Global temperature","SIE","Carbon dioxide","Ice sheets", "Sea level", "Ocean warming");
//         comb.setItems(list);
    
    
         
    }   

    
    
}
